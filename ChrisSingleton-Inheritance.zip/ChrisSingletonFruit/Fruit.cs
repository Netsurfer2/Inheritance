﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChrisSingletonFruit
{
    // Weight property is inherited to the children (Apple & Banana).
    public class Fruit
    {
        public int Weight { get; set; }
    }
}

